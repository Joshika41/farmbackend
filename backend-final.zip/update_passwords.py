import database
from models import User
import uuid

def update_db():
    db = database.SessionLocal()
    try:
        # Credentials from the provided image
        credentials = {
            "david": "9500324356",
            "kalyan": "9600976658",
            "selvaraj": "9941451841",
            "savari": "8778520016",
            "vishwa": "8144581447",
            "mani": "9943411515",
            "shanmugam": "7401757062",
            "raja": "7904983791"
        }
        
        # 1. Update existing employees
        for username, new_password in credentials.items():
            user = db.query(User).filter(User.username == username).first()
            if user:
                user.password = new_password
                user.role = "employee"
                print(f"Updated password for {username}")
            else:
                print(f"Warning: {username} not found in DB")
        
        # 2. Add/Update Admin (Jayanthi)
        jayanthi = db.query(User).filter(User.username == "jayanthi").first()
        if not jayanthi:
            jayanthi = User(
                id=f"emp_{uuid.uuid4().hex[:8]}",
                name="Jayanthi",
                username="jayanthi",
                password="9940084735",
                role="admin",
                avatar="https://ui-avatars.com/api/?name=Jayanthi&background=random"
            )
            db.add(jayanthi)
            print("Added Jayanthi (Admin)")
        else:
            jayanthi.password = "9940084735"
            jayanthi.role = "admin"
            print("Updated Jayanthi (Admin)")

        # 3. Add/Update Owner (Chairman)
        chairman = db.query(User).filter(User.username == "chairman").first()
        if not chairman:
            chairman = User(
                id=f"emp_{uuid.uuid4().hex[:8]}",
                name="Chairman",
                username="chairman",
                password="Chairman@123",
                role="owner",
                avatar="https://ui-avatars.com/api/?name=Chairman&background=random"
            )
            db.add(chairman)
            print("Added Chairman (Owner)")
        else:
            chairman.password = "Chairman@123"
            chairman.role = "owner"
            print("Updated Chairman (Owner)")

        db.commit()
        print("Database credentials update complete!")
        
    except Exception as e:
        print(f"Error: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    update_db()
