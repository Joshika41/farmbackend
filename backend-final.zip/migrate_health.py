import database
from models import Base, User, Task
from sqlalchemy.orm import Session
from sqlalchemy import text
import uuid

def migrate():
    db = database.SessionLocal()
    
    # Ensure Raja exists
    raja_user = db.query(User).filter(User.username == "raja").first()
    if not raja_user:
        raja_user = User(
            id="emp_raja",
            name="Raja",
            username="raja",
            password="employee123",
            role="employee",
            avatar="https://images.unsplash.com/photo-1599566150163-29194dcaad36?w=150&auto=format&fit=crop&q=80"
        )
        db.add(raja_user)
        db.commit()
        print("Created user: Raja")
    
    # Read from the raw table
    query = text("SELECT * FROM `health check list - format(eng)`")
    try:
        result = db.execute(query)
        rows = result.fetchall()
        
        added_count = 0
        for row in rows:
            # Assuming row structure: (S.No, Time, Daily Work, ...)
            s_no = str(row[0]).strip()
            time_val = str(row[1]).strip()
            daily_work = str(row[2]).strip()
            
            # Skip headers and empty rows
            if not s_no or s_no.lower() == 's.no' or not daily_work:
                continue
            
            title = daily_work
            if time_val:
                title = f"[{time_val}] {title}"
                
            new_task = Task(
                id=f"t_{uuid.uuid4().hex[:8]}",
                title=title,
                category="health_check",
                subcategory="Daily Routine",
                status="pending",
                assigned_to=raja_user.id,
                priority="high"
            )
            db.add(new_task)
            added_count += 1
            
        db.commit()
        print(f"Successfully migrated {added_count} health check tasks to Raja!")
        
        # Optional: You can drop the messy table now
        # db.execute(text("DROP TABLE `health check list - format(eng)`"))
        # db.commit()
        
    except Exception as e:
        print(f"Migration failed: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    migrate()
